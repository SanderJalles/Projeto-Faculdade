package com.omegascar.demo.entities.Serviços;

public class Servico {
    private Long id;
    private String nome;

    private Double preco;

    public Servico(Long id, String nome, double preco) {
        this.id = id;
        this.nome = nome;
        this.preco = this.preco;
    }

    public Servico() {
    }
}
