package com.sistemapoo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistampooApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistampooApplication.class, args);
	}

}

